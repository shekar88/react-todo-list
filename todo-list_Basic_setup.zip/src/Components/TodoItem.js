import React, { Component } from 'react'

export default class TodoItem extends Component {
    render() {
        return (
            <div>
                I am TodoItem Component
            </div>
        )
    }
}
