import React, { Component } from 'react'

export default class TodoInput extends Component {
    render() {
        return (
            <div>
                This is TodoInput Component
            </div>
        )
    }
}
